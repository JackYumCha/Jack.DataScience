function findGraphFroms(graphItem: IGraphTrace, edgeQuery: IEdgeQuery): IGraphTrace[]{
    let edgeCollection = db.getCollection<IEdgeCollection>(edgeQuery.edge);
    let results: IGraphTrace[] = [];
    let edgeFilter = edgeQuery.type ? {
        _to: graphItem.vertexId,
        _toCollection: graphItem.vertexType,
        _fromCollection: edgeQuery.type   
    }:{
        _to: graphItem.vertexId,
        _toCollection: graphItem.vertexType,
    };
    let filter = edgeQuery.edgeFilter ? {
        $and: [
            edgeFilter,
            edgeQuery.edgeFilter
        ]
    } : edgeFilter;
    // print(filter);
    let edges = edgeCollection.find(filter);
    edges.forEach(edge => {
        results.push({
            key: edgeQuery.key,
            edgeId: edge._id,
            // yield edge only when marked
            edge: edgeQuery.yieldEdge ? edge : undefined,
            edgeType: edgeQuery.edge,
            direction: -1,
            vertexId: edge._from,
            vertexType: edge._fromCollection,
            depth: edgeQuery.depth,
            withs: {}
        });
    });
    return results;
}