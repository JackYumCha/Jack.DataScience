function findGraphTos(graphItem: IGraphTrace, edgeQuery: IEdgeQuery): IGraphTrace[]{
    let edgeCollection = db.getCollection<IEdgeCollection>(edgeQuery.edge);
    let results: IGraphTrace[] = [];
    let edgeFilter = edgeQuery.type ? {
        _from: graphItem.vertexId,
        _fromCollection: graphItem.vertexType,
        _toCollection: edgeQuery.type   
    }:{
        _from: graphItem.vertexId,
        _fromCollection: graphItem.vertexType
    };
    let filter = edgeQuery.edgeFilter ? {
        $and: [
            edgeFilter,
            edgeQuery.edgeFilter
        ]
    } : edgeFilter;
    // throw(JSON.stringify(filter));
    let edges = edgeCollection.find(filter);
    edges.forEach(edge => {
        results.push({
            key: edgeQuery.key,
            edgeId: edge._id,
            // yield edge only when marked
            edge: edgeQuery.yieldEdge ? edge : undefined,
            edgeType: edgeQuery.edge,
            direction: 1,
            vertexId: edge._to,
            vertexType: edge._toCollection,
            depth: edgeQuery.depth,
            withs: {}
        });
    });
    return results;
}