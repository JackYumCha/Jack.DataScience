function graphQuery(query: IGraphQuery): ISortedGraph {

    let entities: {[key: string]: {[id:string]: ICollection}} = {};
    let traces: IGraphTrace[] = [];
    let result: ISortedGraph = {
        entities: entities,
        graph: traces,
    };

    let items = db.getCollection<ICollection>(query.type).find(query.filter);

    items.forEach(item => {
        let trace: IGraphTrace = {
            key: null,
            vertex: item,
            vertexId: item._id,
            vertexType: query.type,
            depth: 0,
            withs: {},
        };
        for(let key in query.withs){
            let withQuery = query.withs[key];
            trace.withs[key] = graphWith(trace, withQuery);
        }
        traces.push(trace);
    });
    return result;
}