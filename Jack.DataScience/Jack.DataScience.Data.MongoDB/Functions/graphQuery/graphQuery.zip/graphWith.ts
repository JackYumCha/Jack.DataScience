function graphWith(graphItem: IGraphTrace, edgeQuery: IEdgeQuery){
    if(edgeQuery.times <= 0) return []; // stop here if no times count left
    let results: IGraphTrace[] = [];
    switch(edgeQuery.direction){
        case -1:{
            let froms = findGraphFroms(graphItem, edgeQuery);
            froms.forEach(item => {
                findGraphVertex(item, edgeQuery);
                results.push(item);
            });
        }
        break;
        case 0:{
            let froms = findGraphFroms(graphItem, edgeQuery);
            froms.forEach(item => {
                findGraphVertex(item, edgeQuery);
                results.push(item);
            });
            let tos = findGraphTos(graphItem, edgeQuery);
            tos.forEach(item => {
                findGraphVertex(item, edgeQuery);
                results.push(item);
            });
        }
        break;
        case 1:{
            let tos = findGraphTos(graphItem, edgeQuery);
            tos.forEach(item => {
                findGraphVertex(item, edgeQuery);
                results.push(item);
            });
        }
        break;
    }

    // add withs
    results
    .filter(result => result.vertexExists)
    .forEach(result => {
        for(let key in edgeQuery.withs){
            let withQuery = edgeQuery.withs[key];
            result.withs[key] = graphWith(result, withQuery);
        }
    });

    // apply further queries to the results if there are with

    if(edgeQuery.times > 1){
        results
        // .filter(result => result.vertexExists) when recursive, it will continue even vertex does not match vertexFilter
        .map(result => graphWith(result, {
            key: edgeQuery.key,
            edge: edgeQuery.edge,
            type: edgeQuery.type,
            edgeFilter: edgeQuery.edgeFilter,
            vertexFilter: edgeQuery.vertexFilter,
            yieldEdge: true,
            yieldVertex: true,
            direction: edgeQuery.direction,
            times: edgeQuery.times - 1,
            vertexMatches: result.vertexExists? edgeQuery.vertexMatches -1: edgeQuery.vertexMatches,
            depth: edgeQuery.depth + 1,
            withs: edgeQuery.withs,
        }))
        .reduce<IGraphTrace[]>((items, arr)=>{
            items.forEach(item => arr.push(item));
            return arr;
        }, <IGraphTrace[]>[])
        .forEach(result => {
            results.push(result);
        });
    }

    return results;
}