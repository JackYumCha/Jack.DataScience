function findGraphVertex(graphItem: IGraphTrace, edgeQuery: IEdgeQuery): void{
    let vertexCollection = db.getCollection<IEdgeCollection>(graphItem.vertexType);
    let filter = edgeQuery.vertexFilter ? {
        $and: [
            {
                _id: graphItem.vertexId
            },
            edgeQuery.vertexFilter
        ]
    } : {
        _id: graphItem.vertexId
    };
    let vertices = vertexCollection.find(filter);
    if(vertices.hasNext()){
        let vertex = vertices.next();
        graphItem.vertexExists = true;
        if(edgeQuery.yieldVertex){
            graphItem.vertex = vertex;
        }
    }
}